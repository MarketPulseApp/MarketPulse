"""
Domain tier: Data models for the workers.
Provides DTOs and models for communication between layers.
"""
from dataclasses import dataclass, asdict
from typing import Dict, Any

@dataclass
class OHLCVData:
    """
    Data Transfer Object for OHLCV data.
    """
    symbol: str
    timestamp: str
    open: float
    high: float
    low: float
    close: float
    volume: float

    def to_dict(self) -> Dict[str, Any]:
        """Convert the model to a dictionary."""
        return asdict(self)

@dataclass
class MarketDataResult:
    """
    Data Transfer Object for market data fetch results.
    """
    symbol: str
    status: str
    records_inserted: int = 0
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert the model to a dictionary."""
        return asdict(self)

@dataclass
class SentimentAnalysisResult:
    """
    Data Transfer Object for sentiment analysis results.
    """
    source: str
    status: str
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert the model to a dictionary."""
        return asdict(self)

@dataclass
class PredictionResult:
    """
    Data Transfer Object for prediction results.
    """
    symbol: str
    status: str
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert the model to a dictionary."""
        return asdict(self)

@dataclass
class NewsIndexResult:
    """
    Data Transfer Object for news indexing results.
    """
    article_id: str
    status: str
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert the model to a dictionary."""
        return asdict(self)

@dataclass
class TickData:
    """
    Data Transfer Object for real-time tick data.
    """
    symbol: str
    price: float
    volume: float
    timestamp: str

    def to_dict(self) -> Dict[str, Any]:
        """Convert the model to a dictionary."""
        return asdict(self)

@dataclass
class OrderBookData:
    """
    Data Transfer Object for real-time order book data.
    """
    symbol: str
    bids: list
    asks: list
    timestamp: str

    def to_dict(self) -> Dict[str, Any]:
        """Convert the model to a dictionary."""
        return asdict(self)
