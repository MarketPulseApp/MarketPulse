import logging
import yfinance as yf

logger = logging.getLogger(__name__)

class OptionsService:
    """
    Service for fetching Options data via yfinance.
    """
    
    def __init__(self):
        pass

    def fetch_and_process_options_data(self, symbol: str) -> dict:
        """
        Fetches options chain for a symbol, calculates put/call ratio, and logs it.
        """
        logger.info(f"Starting options data fetch for {symbol}...")
        
        try:
            ticker = yf.Ticker(symbol)
            options_dates = ticker.options
            
            if not options_dates:
                logger.warning(f"No options dates found for {symbol}.")
                return {"symbol": symbol, "status": "no_options"}
                
            # Fetch for the nearest expiration date
            nearest_date = options_dates[0]
            chain = ticker.option_chain(nearest_date)
            
            calls = chain.calls
            puts = chain.puts
            
            total_call_volume = calls['volume'].sum() if 'volume' in calls else 0
            total_put_volume = puts['volume'].sum() if 'volume' in puts else 0
            
            put_call_ratio = total_put_volume / total_call_volume if total_call_volume > 0 else 0
            
            data = {
                "symbol": symbol,
                "expiration_date": nearest_date,
                "total_call_volume": int(total_call_volume),
                "total_put_volume": int(total_put_volume),
                "put_call_ratio": round(put_call_ratio, 4)
            }
            
            logger.info(f"Options data for {symbol}: {data}")
            return data
            
        except Exception as e:
            logger.error(f"Failed to fetch options data for {symbol}: {e}")
            return {"symbol": symbol, "status": "error", "error": str(e)}
