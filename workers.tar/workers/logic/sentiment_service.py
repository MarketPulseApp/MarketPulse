"""
Logic tier: Sentiment Service.
Provides business logic for running sentiment analysis on text.
"""
import logging
from workers.domain.models import SentimentAnalysisResult

logger = logging.getLogger(__name__)

class SentimentService:
    """
    Service responsible for sentiment analysis.
    """
    
    def analyze(self, text: str, source: str) -> dict:
        """
        Analyze the sentiment of a given text.
        
        Args:
            text (str): The text to analyze.
            source (str): The origin of the text.
            
        Returns:
            dict: The result of the sentiment analysis.
        """
        logger.info(f"SentimentService: Analyzing text from source={source}")
        text_lower = text.lower()
        if any(word in text_lower for word in ["bull", "surge", "gain", "high", "good", "great"]):
            status = "positive"
        elif any(word in text_lower for word in ["bear", "drop", "loss", "low", "bad", "terrible"]):
            status = "negative"
        else:
            status = "neutral"
            
        result = SentimentAnalysisResult(source=source, status=status)
        return result.to_dict()
