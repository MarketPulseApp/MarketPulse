"""
Logic tier: Ingestion Service.
Provides business logic for processing real-time streaming data.
"""
import logging
from workers.domain.models import TickData, OrderBookData
from workers.data_access.timescale_repository import TimescaleDBRepository

logger = logging.getLogger(__name__)

class IngestionService:
    """
    Service responsible for streaming market data operations.
    """
    
    def __init__(self, repository: TimescaleDBRepository):
        """
        Initializes the service with the required repository.
        """
        self.repository = repository

    async def process_tick(self, tick: TickData):
        """
        Process a single tick data.
        
        Args:
            tick (TickData): The real-time tick data object.
        """
        try:
            await self.repository.insert_tick(
                symbol=tick.symbol,
                price=tick.price,
                volume=tick.volume,
                timestamp=tick.timestamp
            )
            logger.debug(f"IngestionService: Processed tick for {tick.symbol} at {tick.timestamp}")
        except Exception as e:
            logger.error(f"Error processing tick data for {tick.symbol}: {e}")

    async def process_order_book(self, order_book: OrderBookData):
        """
        Process order book snapshot data.
        
        Args:
            order_book (OrderBookData): The real-time order book data object.
        """
        try:
            await self.repository.insert_order_book(
                symbol=order_book.symbol,
                bids=order_book.bids,
                asks=order_book.asks,
                timestamp=order_book.timestamp
            )
            logger.debug(f"IngestionService: Processed order book for {order_book.symbol} at {order_book.timestamp}")
        except Exception as e:
            logger.error(f"Error processing order book data for {order_book.symbol}: {e}")
