"""
Logic tier: News Service.
Provides business logic for processing and indexing news articles.
"""
import logging
import hashlib
from typing import List, Dict, Any
from workers.domain.models import NewsIndexResult
from workers.data_access.api_clients import NewsAPIClient, RedditAPIClient, RSSFeedClient
from workers.data_access.repositories import ElasticsearchRepository
from workers.logic.sentiment_service import SentimentService

logger = logging.getLogger(__name__)

class NewsService:
    """
    Service responsible for news article processing, sentiment analysis, and indexing.
    """
    def __init__(self):
        self.news_api = NewsAPIClient()
        self.reddit_api = RedditAPIClient()
        self.rss_client = RSSFeedClient()
        self.repo = ElasticsearchRepository()
        self.sentiment_service = SentimentService()
        
    def index_article(self, article_id: str, content: str) -> dict:
        """
        Legacy single article indexer.
        """
        logger.info(f"NewsService: Indexing news article {article_id}")
        doc = {"article_id": article_id, "content": content}
        success = self.repo.index_document("news", article_id, doc)
        status = "indexed" if success else "failed"
        result = NewsIndexResult(article_id=article_id, status=status)
        return result.to_dict()

    def fetch_and_process_all(self, rss_feeds: List[str] = None):
        """
        Fetches data from NewsAPI, Reddit, and RSS feeds, calculates sentiment, and indexes them.
        """
        articles = []
        articles.extend(self.news_api.fetch_news())
        articles.extend(self.reddit_api.fetch_posts("wallstreetbets"))
        
        if rss_feeds:
            for feed in rss_feeds:
                articles.extend(self.rss_client.fetch_feed(feed))
                
        processed_count = 0
        for article in articles:
            # Generate deterministic ID
            text = f"{article.get('title', '')} {article.get('description', '')}"
            if not text.strip():
                continue
            doc_id = hashlib.md5(text.encode('utf-8')).hexdigest()
            
            # Analyze sentiment
            sentiment_res = self.sentiment_service.analyze(text, article.get('source', 'unknown'))
            article['sentiment'] = sentiment_res.get('status', 'neutral')
            
            # Index document
            if self.repo.index_document("news", doc_id, article):
                processed_count += 1
                
        return {"status": "success", "processed_count": processed_count}
