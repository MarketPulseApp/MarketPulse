"""
Logic tier: Market Data Service.
Provides business logic for fetching and managing market data.
"""
import logging
from workers.domain.models import MarketDataResult

logger = logging.getLogger(__name__)

class MarketDataService:
    """
    Service responsible for market data operations.
    """
    def __init__(self):
        """
        Initialize the service, injecting dependencies for API clients and repositories.
        """
        from workers.data_access.api_clients import BinanceAPIClient
        from workers.data_access.repositories import PostgresOHLCVRepository
        
        self.api_client = BinanceAPIClient()
        self.repository = PostgresOHLCVRepository()
        
    def fetch_data(self, symbol: str) -> dict:
        """
        Fetch OHLCV data for a given symbol and persist it to the database.
        
        Args:
            symbol (str): The stock symbol.
            
        Returns:
            dict: The result of the operation containing symbol and status.
        """
        logger.info(f"MarketDataService: Fetching market data for {symbol}")
        
        try:
            # Example hardcoded range for backtesting data (e.g. last 100 days).
            # In a real scenario, this would be computed or passed dynamically.
            from datetime import datetime, timedelta
            end_date = datetime.now()
            start_date = end_date - timedelta(days=100)
            
            # 1. Fetch data using Data Access API Client
            records = self.api_client.fetch_historical_data(
                symbol=symbol,
                start_date=start_date.strftime("%Y-%m-%d"),
                end_date=end_date.strftime("%Y-%m-%d")
            )
            
            # 2. Persist data using Data Access Repository
            if records:
                num_inserted = self.repository.insert_batch(records)
                logger.info(f"MarketDataService: Successfully fetched and inserted {num_inserted} records for {symbol}.")
                result = MarketDataResult(symbol=symbol, status="success", records_inserted=num_inserted)
            else:
                logger.warning(f"MarketDataService: No data found for {symbol}.")
                result = MarketDataResult(symbol=symbol, status="no_data", records_inserted=0)
                
            return result.to_dict()
        except Exception as e:
            logger.error(f"MarketDataService: Failed to fetch/store data for {symbol}: {e}")
            result = MarketDataResult(symbol=symbol, status="error", records_inserted=0)
            return result.to_dict()
