import logging
import requests

logger = logging.getLogger(__name__)

class StockTwitsService:
    """
    Service for fetching social sentiment data from StockTwits.
    """
    
    def __init__(self):
        pass

    def fetch_and_process_stocktwits_data(self, symbol: str) -> dict:
        """
        Fetches recent StockTwits messages for a given symbol.
        """
        logger.info(f"Starting StockTwits data fetch for {symbol}...")
        
        url = f'https://api.stocktwits.com/api/2/streams/symbol/{symbol}.json'
        
        try:
            # Added User-Agent just in case
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
            }
            response = requests.get(url, headers=headers, timeout=10)
            response.raise_for_status()
            
            data = response.json()
            messages = data.get('messages', [])
            
            logger.info(f"Fetched {len(messages)} messages for {symbol} from StockTwits.")
            
            # Here we might send the messages to the SentimentService or Elasticsearch
            # For now, just summarize
            summary = {
                "symbol": symbol,
                "message_count": len(messages),
                "status": "success"
            }
            
            return summary
            
        except requests.exceptions.RequestException as e:
            logger.error(f"Failed to fetch StockTwits data for {symbol}: {e}")
            return {"symbol": symbol, "status": "error", "error": str(e)}
