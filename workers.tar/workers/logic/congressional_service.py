import logging
import random
from workers.data_access.repositories import InsiderGraphRepository

logger = logging.getLogger(__name__)

class CongressionalTradingService:
    """
    Service for mocking and ingesting Congressional Trading data into Neo4j.
    """
    
    def __init__(self):
        self.repository = InsiderGraphRepository()
        self.politicians = ["Pelosi", "Tuberville", "Khanna", "Scott", "McCaul"]
        self.tickers = ["AAPL", "MSFT", "NVDA", "TSLA", "AMZN", "GOOGL"]

    def fetch_and_process_congressional_data(self) -> None:
        """
        Mocks fetching congressional trading data and ingests it into Neo4j.
        """
        logger.info("Starting mock congressional data fetch and ingest...")
        
        # Generate some mock data
        num_transactions = random.randint(2, 5)
        for _ in range(num_transactions):
            politician = random.choice(self.politicians)
            symbol = random.choice(self.tickers)
            tx_type = random.choice(["CONGRESSIONAL_BOUGHT", "CONGRESSIONAL_SOLD"])
            
            logger.info(f"Ingesting: {politician} {tx_type} {symbol}")
            try:
                self.repository.add_congressional_transaction(politician, symbol, tx_type)
            except Exception as e:
                logger.error(f"Failed to ingest transaction for {politician} on {symbol}: {e}")
                
        logger.info("Finished congressional data ingest.")

    def close(self):
        self.repository.close()
