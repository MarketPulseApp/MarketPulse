"""
Main entry point for the background workers.
Starts an HTTP server for health checking and Prometheus metrics,
and then launches the Celery worker.
"""
import asyncio
import logging
import threading

from aiohttp import web
from celery.bin import worker
from workers.celery_app import app

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

async def health_check(request):
    """
    Basic health check endpoint.
    
    Args:
        request: The incoming aiohttp request.
        
    Returns:
        web.Response: JSON response indicating status.
    """
    return web.json_response({"status": "ok", "service": "marketpulse-celery-worker"})

async def metrics(request):
    """
    Basic Prometheus metrics exposition.
    
    Args:
        request: The incoming aiohttp request.
        
    Returns:
        web.Response: Plain text response containing metrics.
    """
    return web.Response(text="# HELP worker_up Whether the worker is running.\\n# TYPE worker_up gauge\\nworker_up 1\\n")

async def start_http_server():
    """
    Start the aiohttp server for health and metrics on port 8082.
    """
    web_app = web.Application()
    web_app.add_routes([
        web.get('/health', health_check),
        web.get('/metrics', metrics)
    ])
    runner = web.AppRunner(web_app)
    await runner.setup()
    site = web.TCPSite(runner, '0.0.0.0', 8082)
    await site.start()
    logger.info("Worker HTTP server running on port 8082")
    
    # Keep the event loop running
    while True:
        await asyncio.sleep(3600)

def run_http_server_in_thread():
    """
    Runs the asyncio HTTP server in a separate thread.
    """
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.run_until_complete(start_http_server())

if __name__ == "__main__":
    # Start health check server
    t = threading.Thread(target=run_http_server_in_thread, daemon=True)
    t.start()
    
    # Start Celery worker programmatically
    argv = [
        'worker',
        '--loglevel=INFO',
        '-B',
    ]
    app.worker_main(argv)
