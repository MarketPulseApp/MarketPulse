"""
Data Access tier: Repositories for background workers.
Abstracts database operations (e.g., Neo4j, TimescaleDB, Elasticsearch).
"""
import logging
import os
from neo4j import GraphDatabase

logger = logging.getLogger(__name__)

class GraphRepository:
    """
    Repository for interacting with Neo4j Graph Database.
    """
    
    def __init__(self):
        """
        Initializes the repository and the Neo4j driver using environment variables.
        """
        uri = os.getenv("NEO4J_URI", "neo4j://localhost:7687").strip()
        username = os.getenv("NEO4J_USERNAME", "neo4j").strip()
        password = os.getenv("NEO4J_PASSWORD", "password").strip()
        self.database = os.getenv("NEO4J_DATABASE", "neo4j").strip()
        
        try:
            self.driver = GraphDatabase.driver(uri, auth=(username, password))
        except Exception as exc:
            logger.error(f"Failed to initialize GraphDatabase driver: {exc}")
            self.driver = None

    def close(self):
        """
        Closes the Neo4j driver connection.
        """
        if self.driver:
            self.driver.close()

    def run_query(self, query: str, parameters: dict = None) -> list:
        """
        Executes a query against the graph database.
        
        Args:
            query (str): Cypher query string.
            parameters (dict, optional): Parameters for the query. Defaults to None.
            
        Returns:
            list: The list of records returned by the query.
        """
        if not self.driver:
            logger.warning("GraphDatabase driver is not initialized.")
            return []
            
        session_kwargs = {}
        if self.database:
            session_kwargs['database'] = self.database
            
        with self.driver.session(**session_kwargs) as session:
            result = session.run(query, parameters or {})
            return [record.data() for record in result]

class PostgresOHLCVRepository:
    """
    Repository for interacting with PostgreSQL (or TimescaleDB) for OHLCV data.
    """
    def __init__(self):
        """
        Initializes the repository and the PostgreSQL connection using environment variables.
        """
        self.host = os.getenv("POSTGRES_HOST", "localhost")
        self.port = os.getenv("POSTGRES_PORT", "5432")
        self.user = os.getenv("POSTGRES_USER", "postgres")
        self.password = os.getenv("POSTGRES_PASSWORD", "password")
        self.database = os.getenv("POSTGRES_DATABASE", "postgres")

    def insert_batch(self, records: list) -> int:
        """
        Inserts a batch of OHLCVData records into the database.
        
        Args:
            records (list): A list of OHLCVData models.
            
        Returns:
            int: Number of records inserted.
        """
        import psycopg2
        from psycopg2.extras import execute_values
        
        # Connection string
        conn_str = f"host={self.host} port={self.port} dbname={self.database} user={self.user} password={self.password}"
        
        try:
            with psycopg2.connect(conn_str) as conn:
                with conn.cursor() as cursor:
                    # Assuming a table named 'ohlcv_data' exists with these columns.
                    # Adjust query if there's a specific function like fn_insert_ohlcv.
                    query = """
                        INSERT INTO ohlcv (timestamp, symbol, open, high, low, close, volume)
                        VALUES %s
                        ON CONFLICT (timestamp, symbol) DO NOTHING;
                    """
                    values = [
                        (r.timestamp, r.symbol, r.open, r.high, r.low, r.close, r.volume)
                        for r in records
                    ]
                    
                    # Using psycopg2.extras.execute_values for fast batch insert
                    execute_values(cursor, query, values)
                    return len(values)
        except Exception as exc:
            logger.error(f"Failed to insert batch of OHLCV data: {exc}")
            return 0

class ElasticsearchRepository:
    """
    Repository for interacting with Elasticsearch for full-text search indexing (e.g. news).
    """
    def __init__(self):
        self.url = os.getenv("ELASTIC_URL", "http://elastic:marketpulse_password_1122@192.168.1.162:9200")
        
    def index_document(self, index_name: str, doc_id: str, document: dict) -> bool:
        """
        Index a document in Elasticsearch.
        """
        import requests
        try:
            url = f"{self.url}/{index_name}/_doc/{doc_id}"
            response = requests.post(url, json=document, timeout=5)
            response.raise_for_status()
            return True
        except Exception as exc:
            logger.error(f"Failed to index document in Elasticsearch: {exc}")
            return False

class InsiderGraphRepository(GraphRepository):
    """
    Repository for interacting with Neo4j to store insider trading data.
    """
    
    def add_transaction(self, person: str, symbol: str, transaction_type: str) -> None:
        """
        Creates a (Person)-[:INSIDER_BOUGHT/SOLD]->(Ticker) relationship.
        
        Args:
            person (str): The name of the insider.
            symbol (str): The ticker symbol.
            transaction_type (str): Either 'INSIDER_BOUGHT' or 'INSIDER_SOLD'.
        """
        if transaction_type not in ["INSIDER_BOUGHT", "INSIDER_SOLD"]:
            logger.warning(f"Invalid transaction type: {transaction_type}")
            return
            
        # Cypher doesn't allow parameterizing relationship types directly in MERGE/CREATE,
        # so we inject the validated transaction_type string into the query.
        query = f"""
        MERGE (p:Person {{name: $person}})
        MERGE (t:Ticker {{symbol: $symbol}})
        MERGE (p)-[:{transaction_type}]->(t)
        """
        self.run_query(query, {"person": person, "symbol": symbol})

    def add_congressional_transaction(self, politician: str, symbol: str, transaction_type: str) -> None:
        """
        Creates a (Politician)-[:CONGRESSIONAL_BOUGHT/SOLD]->(Ticker) relationship.
        
        Args:
            politician (str): The name of the politician.
            symbol (str): The ticker symbol.
            transaction_type (str): Either 'CONGRESSIONAL_BOUGHT' or 'CONGRESSIONAL_SOLD'.
        """
        if transaction_type not in ["CONGRESSIONAL_BOUGHT", "CONGRESSIONAL_SOLD"]:
            logger.warning(f"Invalid transaction type: {transaction_type}")
            return
            
        query = f"""
        MERGE (p:Politician {{name: $politician}})
        MERGE (t:Ticker {{symbol: $symbol}})
        MERGE (p)-[:{transaction_type}]->(t)
        """
        self.run_query(query, {"politician": politician, "symbol": symbol})

