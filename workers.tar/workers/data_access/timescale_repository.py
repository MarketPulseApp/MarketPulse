"""
Data Access tier: Repository for TimescaleDB.
Abstracts database operations for real-time market data ingestion.
"""
import logging
import os
import asyncpg
import json

logger = logging.getLogger(__name__)

class TimescaleDBRepository:
    """
    Repository for interacting with TimescaleDB (PostgreSQL) asynchronously.
    """

    def __init__(self):
        """
        Initializes the repository connection pool settings.
        """
        self.dsn = os.getenv("POSTGRES_URL", "postgresql://marketpulse:marketpulse_password_1122@192.168.1.123:5432/marketpulse")
        self.pool = None

    async def connect(self):
        """
        Creates an asyncpg connection pool.
        """
        if not self.pool:
            try:
                self.pool = await asyncpg.create_pool(dsn=self.dsn)
                await self._init_schema()
                logger.info("Successfully connected to TimescaleDB and verified schema.")
            except Exception as exc:
                logger.error(f"Failed to connect to TimescaleDB: {exc}")

    async def close(self):
        """
        Closes the connection pool.
        """
        if self.pool:
            await self.pool.close()

    async def _init_schema(self):
        """
        Initializes the TimescaleDB hypertables if they don't exist.
        """
        query_ticks = """
        CREATE TABLE IF NOT EXISTS ticks (
            time TIMESTAMPTZ NOT NULL,
            symbol TEXT NOT NULL,
            price DOUBLE PRECISION NOT NULL,
            volume DOUBLE PRECISION NOT NULL
        );
        SELECT create_hypertable('ticks', 'time', if_not_exists => TRUE);
        """
        
        query_order_book = """
        CREATE TABLE IF NOT EXISTS order_books (
            time TIMESTAMPTZ NOT NULL,
            symbol TEXT NOT NULL,
            bids JSONB NOT NULL,
            asks JSONB NOT NULL
        );
        SELECT create_hypertable('order_books', 'time', if_not_exists => TRUE);
        """
        
        async with self.pool.acquire() as conn:
            # We ignore errors from create_hypertable if it's already a hypertable, 
            # but asyncpg might throw an exception if we don't handle it gracefully.
            # Using DO block or simple execution.
            try:
                await conn.execute(query_ticks)
            except Exception as e:
                logger.warning(f"Hypertable ticks init msg: {e}")
                
            try:
                await conn.execute(query_order_book)
            except Exception as e:
                logger.warning(f"Hypertable order_books init msg: {e}")

    async def insert_tick(self, symbol: str, price: float, volume: float, timestamp: str):
        """
        Inserts a single tick into TimescaleDB.
        """
        if not self.pool:
            logger.warning("TimescaleDB pool is not initialized.")
            return

        query = "INSERT INTO ticks (time, symbol, price, volume) VALUES ($1, $2, $3, $4)"
        async with self.pool.acquire() as conn:
            import datetime
            dt = datetime.datetime.fromisoformat(timestamp)
            await conn.execute(query, dt, symbol, price, volume)

    async def insert_order_book(self, symbol: str, bids: list, asks: list, timestamp: str):
        """
        Inserts an order book snapshot into TimescaleDB.
        """
        if not self.pool:
            logger.warning("TimescaleDB pool is not initialized.")
            return

        query = "INSERT INTO order_books (time, symbol, bids, asks) VALUES ($1, $2, $3, $4)"
        async with self.pool.acquire() as conn:
            import datetime
            dt = datetime.datetime.fromisoformat(timestamp)
            await conn.execute(query, dt, symbol, json.dumps(bids), json.dumps(asks))
