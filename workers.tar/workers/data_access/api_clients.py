"""
Data Access tier: Market Data API clients.
Handles interactions with external REST APIs (e.g., Binance, Alpaca, Polygon).
Follows SOLID principles, specifically Dependency Inversion via the base class.
"""
import logging
import requests
import feedparser
import os
from typing import List, Optional, Dict, Any
from datetime import datetime
from workers.domain.models import OHLCVData

logger = logging.getLogger(__name__)

class MarketDataAPIClient:
    """
    Abstract base class for market data API clients.
    """
    def fetch_historical_data(self, symbol: str, start_date: str, end_date: str) -> List[OHLCVData]:
        """
        Fetch historical OHLCV data.
        
        Args:
            symbol (str): The stock or crypto symbol.
            start_date (str): The start date in YYYY-MM-DD format.
            end_date (str): The end date in YYYY-MM-DD format.
            
        Returns:
            List[OHLCVData]: A list of OHLCVData objects.
        """
        raise NotImplementedError("Subclasses must implement fetch_historical_data")

class BinanceAPIClient(MarketDataAPIClient):
    """
    Client for fetching data from Binance REST API.
    """
    BASE_URL = "https://api.binance.com/api/v3"

    def fetch_historical_data(self, symbol: str, start_date: str, end_date: str) -> List[OHLCVData]:
        """
        Fetch historical klines (OHLCV) from Binance.
        """
        logger.info(f"BinanceAPIClient: Fetching data for {symbol} from {start_date} to {end_date}")
        
        url = f"{self.BASE_URL}/klines"
        # In a production app, start_date/end_date should be converted to milliseconds timestamps.
        # Here we just fetch the latest 100 days for simplicity of the example.
        params = {
            "symbol": symbol.upper(),
            "interval": "1d",
            "limit": 100
        }
        
        try:
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            data = response.json()
            
            results = []
            for row in data:
                # Binance returns [open_time, open, high, low, close, volume, ...]
                dt = datetime.fromtimestamp(row[0] / 1000.0)
                results.append(OHLCVData(
                    symbol=symbol,
                    timestamp=dt.isoformat(),
                    open=float(row[1]),
                    high=float(row[2]),
                    low=float(row[3]),
                    close=float(row[4]),
                    volume=float(row[5])
                ))
            return results
        except requests.RequestException as e:
            logger.error(f"BinanceAPIClient: Error fetching data for {symbol}: {e}")
            raise

class NewsAPIClient:
    """
    Client for fetching data from NewsAPI.
    """
    BASE_URL = "https://newsapi.org/v2"

    def __init__(self):
        self.api_key = os.getenv("NEWSAPI_KEY")

    def fetch_news(self, query: str = "finance OR crypto OR stock", limit: int = 10) -> List[Dict[str, Any]]:
        if not self.api_key:
            logger.warning("NewsAPIClient: NEWSAPI_KEY not set in environment.")
            return []
        
        url = f"{self.BASE_URL}/everything"
        params = {
            "q": query,
            "apiKey": self.api_key,
            "pageSize": limit,
            "language": "en",
            "sortBy": "publishedAt"
        }
        
        try:
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            data = response.json()
            articles = data.get("articles", [])
            return [{"title": a.get("title"), "description": a.get("description"), "url": a.get("url"), "publishedAt": a.get("publishedAt"), "source": a.get("source", {}).get("name"), "type": "newsapi"} for a in articles]
        except requests.RequestException as e:
            logger.error(f"NewsAPIClient: Error fetching data: {e}")
            return []

class RedditAPIClient:
    """
    Client for fetching data from Reddit via JSON REST.
    """
    def fetch_posts(self, subreddit: str = "wallstreetbets", limit: int = 10) -> List[Dict[str, Any]]:
        url = f"https://www.reddit.com/r/{subreddit}/new.json"
        headers = {"User-Agent": "MarketPulse/1.0"}
        params = {"limit": limit}
        
        try:
            response = requests.get(url, headers=headers, params=params, timeout=10)
            response.raise_for_status()
            data = response.json()
            posts = data.get("data", {}).get("children", [])
            return [{"title": p["data"].get("title"), "description": p["data"].get("selftext"), "url": p["data"].get("url"), "publishedAt": p["data"].get("created_utc"), "source": f"reddit_r_{subreddit}", "type": "reddit"} for p in posts]
        except requests.RequestException as e:
            logger.error(f"RedditAPIClient: Error fetching data from Reddit: {e}")
            return []

class RSSFeedClient:
    """
    Client for fetching generic RSS feeds.
    """
    def fetch_feed(self, feed_url: str) -> List[Dict[str, Any]]:
        try:
            parsed = feedparser.parse(feed_url)
            entries = parsed.entries
            return [{"title": e.get("title"), "description": e.get("summary", e.get("description")), "url": e.get("link"), "publishedAt": e.get("published"), "source": feed_url, "type": "rss"} for e in entries]
        except Exception as e:
            logger.error(f"RSSFeedClient: Error parsing feed {feed_url}: {e}")
            return []
