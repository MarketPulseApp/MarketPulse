import os
import sys

def ping_astra():
    print("Pinging DataStax Astra...")
    try:
        from cassandra.cluster import Cluster
        from cassandra.auth import PlainTextAuthProvider

        bundle_path = os.getenv('ASTRA_DB_SECURE_BUNDLE_PATH')
        if not bundle_path:
            print("Error: ASTRA_DB_SECURE_BUNDLE_PATH not set.")
            return False
        bundle_path = bundle_path.strip()

        cloud_config = {'secure_connect_bundle': bundle_path}
        
        astra_token = os.getenv('ASTRA_DB_APPLICATION_TOKEN', '').strip()
        auth_provider = PlainTextAuthProvider('token', astra_token)
            
        cluster = Cluster(cloud=cloud_config, auth_provider=auth_provider)
        session = cluster.connect()
        row = session.execute("SELECT release_version FROM system.local").one()
        if row:
            print(f"DataStax Astra Ping Successful! Release version: {row.release_version}")
            cluster.shutdown()
            return True
        else:
            print("DataStax Astra Ping Failed: No data returned.")
            cluster.shutdown()
            return False
    except Exception as e:
        print(f"DataStax Astra Ping Exception: {e}")
        return False

def ping_neo4j():
    print("Pinging Neo4j...")
    try:
        from neo4j import GraphDatabase

        uri = os.getenv('NEO4J_URI', '').strip()
        username = os.getenv('NEO4J_USERNAME', '').strip()
        password = os.getenv('NEO4J_PASSWORD', '').strip()
        database = os.getenv('NEO4J_DATABASE', '').strip()

        if not uri or not username or not password:
            print("Error: Neo4j credentials not fully set in environment.")
            return False

        driver = GraphDatabase.driver(uri, auth=(username, password))
        
        session_kwargs = {}
        if database:
            session_kwargs['database'] = database
            
        with driver.session(**session_kwargs) as session:
            result = session.run("RETURN 1 AS alive")
            record = result.single()
            if record and record["alive"] == 1:
                print("Neo4j Ping Successful!")
                driver.close()
                return True
            else:
                print("Neo4j Ping Failed: Unexpected response.")
                driver.close()
                return False
    except Exception as e:
        print(f"Neo4j Ping Exception: {e}")
        return False

if __name__ == "__main__":
    print("Starting database keepalive ping...")
    astra_ok = ping_astra()
    neo4j_ok = ping_neo4j()
    
    if astra_ok and neo4j_ok:
        print("Keepalive check completed successfully.")
        sys.exit(0)
    else:
        print("Keepalive check encountered errors.")
        sys.exit(1)
