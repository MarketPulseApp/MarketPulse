"""
Presentation tier: WebSocket Listeners for real-time market data ingestion.
Connects to external providers (e.g., Binance) and routes data to the Logic tier.
"""
import asyncio
import json
import logging
import websockets
from datetime import datetime, timezone
from workers.domain.models import TickData, OrderBookData
from workers.logic.ingestion_service import IngestionService
from workers.data_access.timescale_repository import TimescaleDBRepository

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class BinanceWebSocketListener:
    """
    WebSocket listener for Binance streams (Trade and Depth).
    """
    
    BINANCE_WS_URL = "wss://stream.binance.com:9443/ws"

    def __init__(self, symbols: list, ingestion_service: IngestionService):
        """
        Initializes the WebSocket listener.
        
        Args:
            symbols (list): List of symbols to subscribe to (e.g. ['btcusdt', 'ethusdt']).
            ingestion_service (IngestionService): The logic service for processing data.
        """
        self.symbols = [s.lower() for s in symbols]
        self.ingestion_service = ingestion_service

    async def _subscribe(self, websocket):
        """
        Sends the subscription message to Binance.
        """
        streams = []
        for symbol in self.symbols:
            streams.append(f"{symbol}@trade")
            streams.append(f"{symbol}@depth10@100ms")  # 10 levels, 100ms updates
            
        subscribe_msg = {
            "method": "SUBSCRIBE",
            "params": streams,
            "id": 1
        }
        await websocket.send(json.dumps(subscribe_msg))
        logger.info(f"Subscribed to streams: {streams}")

    async def _handle_message(self, message: str):
        """
        Parses and routes the incoming WebSocket message.
        """
        data = json.loads(message)
        
        # Trade event (Tick)
        if data.get("e") == "trade":
            tick = TickData(
                symbol=data.get("s", "UNKNOWN").upper(),
                price=float(data.get("p", 0.0)),
                volume=float(data.get("q", 0.0)),
                timestamp=datetime.fromtimestamp(data.get("T", 0) / 1000.0, tz=timezone.utc).isoformat()
            )
            await self.ingestion_service.process_tick(tick)
            
        # Depth event (Order Book Snapshot via stream)
        # Binance partial book depth stream doesn't have an "e" event type, but it has "lastUpdateId"
        elif "lastUpdateId" in data and "bids" in data and "asks" in data:
            # We need to extract symbol if it's sent in a combined stream, or assume if singular.
            # Using partial depth streams without combined stream usually doesn't include the symbol.
            # We'll use a placeholder or handle combined streams if needed. 
            # Assuming raw stream where we might need to rely on the stream name or modify subscription to use combined.
            # Actually, standard partial book depth includes bids and asks. 
            # To know the symbol, we should use combined streams. Let's assume symbol is extracted if possible, or fallback.
            pass

class BinanceCombinedWebSocketListener(BinanceWebSocketListener):
    """
    WebSocket listener using Binance Combined Streams.
    """
    BINANCE_WS_URL = "wss://stream.binance.us:9443/stream"

    async def _subscribe(self, websocket):
        """
        Sends the subscription message to Binance using combined stream format.
        """
        streams = []
        for symbol in self.symbols:
            streams.append(f"{symbol}@trade")
            streams.append(f"{symbol}@depth10@100ms")
            
        subscribe_msg = {
            "method": "SUBSCRIBE",
            "params": streams,
            "id": 1
        }
        await websocket.send(json.dumps(subscribe_msg))
        logger.info(f"Subscribed to combined streams: {streams}")

    async def _handle_message(self, message: str):
        """
        Parses and routes the incoming WebSocket message from combined stream.
        """
        payload = json.loads(message)
        
        # Combined streams have {"stream": "...", "data": {...}}
        stream_name = payload.get("stream", "")
        data = payload.get("data", {})
        
        if not data:
            return

        # Trade event (Tick)
        if data.get("e") == "trade":
            tick = TickData(
                symbol=data.get("s", "UNKNOWN").upper(),
                price=float(data.get("p", 0.0)),
                volume=float(data.get("q", 0.0)),
                timestamp=datetime.fromtimestamp(data.get("T", 0) / 1000.0, tz=timezone.utc).isoformat()
            )
            await self.ingestion_service.process_tick(tick)
            
        # Partial Book Depth event (Order Book)
        elif "lastUpdateId" in data and "bids" in data and "asks" in data:
            # stream_name is like btcusdt@depth10@100ms
            symbol = stream_name.split("@")[0].upper()
            
            order_book = OrderBookData(
                symbol=symbol,
                bids=data["bids"],
                asks=data["asks"],
                # depth streams don't always have a timestamp, use current time
                timestamp=datetime.now(timezone.utc).isoformat()
            )
            await self.ingestion_service.process_order_book(order_book)

    async def run(self):
        """
        Main loop to connect and listen to the WebSocket.
        """
        async for websocket in websockets.connect(self.BINANCE_WS_URL):
            try:
                await self._subscribe(websocket)
                async for message in websocket:
                    await self._handle_message(message)
            except websockets.ConnectionClosed:
                logger.warning("WebSocket connection closed. Reconnecting...")
                continue
            except Exception as e:
                logger.error(f"WebSocket error: {e}")
                await asyncio.sleep(5)

async def start_ingestion(symbols: list):
    """
    Entry point for starting the WebSocket listener.
    """
    repository = TimescaleDBRepository()
    await repository.connect()
    
    ingestion_service = IngestionService(repository)
    listener = BinanceCombinedWebSocketListener(symbols, ingestion_service)
    
    logger.info("Starting Binance WebSocket listener...")
    try:
        await listener.run()
    finally:
        await repository.close()

if __name__ == "__main__":
    # Example usage: python -m workers.presentation.websocket_listener
    asyncio.run(start_ingestion(["BTCUSDT", "ETHUSDT"]))
