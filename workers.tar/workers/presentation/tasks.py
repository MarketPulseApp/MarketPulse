"""
Presentation tier for background workers.
This module defines the Celery tasks which act as the entry points for background processing.
Tasks handle exponential backoff and retries for fault tolerance.
"""
import logging
from workers.celery_app import app
from workers.logic.market_data_service import MarketDataService
from workers.logic.sentiment_service import SentimentService
from workers.logic.prediction_service import PredictionService
from workers.logic.news_service import NewsService

logger = logging.getLogger(__name__)

@app.task(bind=True, max_retries=5, default_retry_delay=5)
def fetch_market_data_task(self, symbol: str):
    """
    Fetch OHLCV data for a symbol and store it.
    
    Args:
        symbol (str): The stock symbol.
        
    Returns:
        dict: Status of the fetch operation.
    """
    try:
        service = MarketDataService()
        return service.fetch_data(symbol)
    except Exception as exc:
        logger.error(f"Error fetching market data for {symbol}: {exc}")
        # Exponential backoff
        countdown = 2 ** self.request.retries
        raise self.retry(exc=exc, countdown=countdown)


@app.task(bind=True, max_retries=5, default_retry_delay=5)
def run_sentiment_analysis_task(self, text: str, source: str):
    """
    Run sentiment analysis on a piece of text.
    
    Args:
        text (str): The text to analyze.
        source (str): The source of the text.
        
    Returns:
        dict: Status of the sentiment analysis.
    """
    try:
        service = SentimentService()
        return service.analyze(text, source)
    except Exception as exc:
        logger.error(f"Error running sentiment analysis: {exc}")
        countdown = 2 ** self.request.retries
        raise self.retry(exc=exc, countdown=countdown)


@app.task(bind=True, max_retries=5, default_retry_delay=5)
def generate_prediction_task(self, symbol: str):
    """
    Generate price prediction for a symbol.
    
    Args:
        symbol (str): The stock symbol.
        
    Returns:
        dict: Status of the prediction.
    """
    try:
        service = PredictionService()
        return service.predict(symbol)
    except Exception as exc:
        logger.error(f"Error generating prediction for {symbol}: {exc}")
        countdown = 2 ** self.request.retries
        raise self.retry(exc=exc, countdown=countdown)


@app.task(bind=True, max_retries=5, default_retry_delay=5)
def index_news_article_task(self, article_id: str, content: str):
    """
    Index a news article into Elasticsearch.
    
    Args:
        article_id (str): The unique identifier of the article.
        content (str): The textual content of the article.
        
    Returns:
        dict: Status of the indexing operation.
    """
    try:
        service = NewsService()
        return service.index_article(article_id, content)
    except Exception as exc:
        logger.error(f"Error indexing article {article_id}: {exc}")
        countdown = 2 ** self.request.retries
        raise self.retry(exc=exc, countdown=countdown)

@app.task(bind=True, max_retries=3, default_retry_delay=60)
def poll_news_sources_task(self):
    """
    Poll various news sources (NewsAPI, Reddit, RSS) and index the articles.
    
    Returns:
        dict: Status of the polling operation.
    """
    try:
        service = NewsService()
        # Define some common RSS feeds here or load from config
        rss_feeds = [
            "https://feeds.a.dj.com/rss/RSSMarketsMain.xml",
            "https://finance.yahoo.com/news/rssindex"
        ]
        return service.fetch_and_process_all(rss_feeds=rss_feeds)
    except Exception as exc:
        logger.error(f"Error polling news sources: {exc}")
        countdown = 2 ** self.request.retries
        raise self.retry(exc=exc, countdown=countdown)

@app.task(bind=True, max_retries=3, default_retry_delay=60)
def poll_insider_data_task(self):
    """
    Poll insider trading data and store it in Neo4j.
    
    Returns:
        dict: Status of the polling operation.
    """
    from workers.logic.insider_service import InsiderTradingService
    try:
        service = InsiderTradingService()
        service.fetch_and_process_insider_data()
        service.close()
        return {"status": "success", "message": "Insider data polled successfully."}
    except Exception as exc:
        logger.error(f"Error polling insider data: {exc}")
        countdown = 2 ** self.request.retries
        raise self.retry(exc=exc, countdown=countdown)

@app.task(bind=True, max_retries=3, default_retry_delay=60)
def poll_macro_data_task(self):
    from workers.logic.macro_service import MacroeconomicService
    try:
        service = MacroeconomicService()
        return service.fetch_and_process_macro_data()
    except Exception as exc:
        logger.error(f"Error polling macro data: {exc}")
        countdown = 2 ** self.request.retries
        raise self.retry(exc=exc, countdown=countdown)

@app.task(bind=True, max_retries=3, default_retry_delay=60)
def fetch_options_data_task(self, symbol: str):
    from workers.logic.options_service import OptionsService
    try:
        service = OptionsService()
        return service.fetch_and_process_options_data(symbol)
    except Exception as exc:
        logger.error(f"Error fetching options data for {symbol}: {exc}")
        countdown = 2 ** self.request.retries
        raise self.retry(exc=exc, countdown=countdown)

@app.task(bind=True, max_retries=3, default_retry_delay=60)
def fetch_stocktwits_data_task(self, symbol: str):
    from workers.logic.stocktwits_service import StockTwitsService
    try:
        service = StockTwitsService()
        return service.fetch_and_process_stocktwits_data(symbol)
    except Exception as exc:
        logger.error(f"Error fetching StockTwits data for {symbol}: {exc}")
        countdown = 2 ** self.request.retries
        raise self.retry(exc=exc, countdown=countdown)

@app.task(bind=True, max_retries=3, default_retry_delay=60)
def poll_congressional_data_task(self):
    from workers.logic.congressional_service import CongressionalTradingService
    try:
        service = CongressionalTradingService()
        service.fetch_and_process_congressional_data()
        service.close()
        return {"status": "success", "message": "Congressional data polled successfully."}
    except Exception as exc:
        logger.error(f"Error polling congressional data: {exc}")
        countdown = 2 ** self.request.retries
        raise self.retry(exc=exc, countdown=countdown)


