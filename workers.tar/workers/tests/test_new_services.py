import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))

import logging
logging.basicConfig(level=logging.INFO)

from workers.logic.macro_service import MacroeconomicService
from workers.logic.options_service import OptionsService
from workers.logic.stocktwits_service import StockTwitsService
from workers.logic.congressional_service import CongressionalTradingService

def test_services():
    try:
        print("Testing Macro Service...")
        macro = MacroeconomicService()
        macro.fetch_and_process_macro_data()
        print("Macro Service passed.\n")
        
        print("Testing Options Service...")
        options = OptionsService()
        options.fetch_and_process_options_data("AAPL")
        print("Options Service passed.\n")
        
        print("Testing StockTwits Service...")
        stocktwits = StockTwitsService()
        stocktwits.fetch_and_process_stocktwits_data("AAPL")
        print("StockTwits Service passed.\n")
        
        print("Testing Congressional Trading Service...")
        congressional = CongressionalTradingService()
        congressional.fetch_and_process_congressional_data()
        congressional.close()
        print("Congressional Service passed.\n")
        
    except Exception as e:
        print(f"Test failed: {e}")

if __name__ == "__main__":
    test_services()
