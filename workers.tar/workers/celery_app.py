"""
Celery Application module.
This module configures and creates the Celery application for background job processing,
utilizing RabbitMQ as the message broker.
"""
import os
from celery import Celery

# Use a default RabbitMQ URL if not provided via environment variables.
RABBITMQ_URL = os.getenv("RABBITMQ_URL", "amqp://guest:guest@localhost:5672//")

app = Celery(
    "marketpulse_workers",
    broker=RABBITMQ_URL,
    backend="rpc://",  # Using RPC for simple backend results
    include=["workers.presentation.tasks"]
)

app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="UTC",
    enable_utc=True,
    task_acks_late=True, # Fault tolerance: acknowledge task only after execution
    task_reject_on_worker_lost=True, # Retry if worker dies
)

# Celery Beat schedule for periodic tasks
from celery.schedules import crontab

app.conf.beat_schedule = {
    'poll-news-every-hour': {
        'task': 'workers.presentation.tasks.poll_news_sources_task',
        'schedule': crontab(minute='0'),  # Run every hour at minute 0
    },
    'poll-insider-data-every-day': {
        'task': 'workers.presentation.tasks.poll_insider_data_task',
        'schedule': crontab(hour='2', minute='0'),  # Run daily at 2:00 AM
    },
    'poll-macro-data-every-day': {
        'task': 'workers.presentation.tasks.poll_macro_data_task',
        'schedule': crontab(hour='3', minute='0'),
    },
    'poll-congressional-data-every-day': {
        'task': 'workers.presentation.tasks.poll_congressional_data_task',
        'schedule': crontab(hour='4', minute='0'),
    }
}

